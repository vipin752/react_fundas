import { useEffect, useState } from "react";

export interface IProps {
    initialValue: number;
  }
  export interface IState {
    count: number;
    hideComponent: boolean;
  }

export function LifeCycleMehodWithFunction(props: IProps) {
    const [count, setCount] = useState(props.initialValue);
    //only one time call like component did mount
    useState(() => {
        console.log("one time eefect");
        setCount(count+1);
    });

    //component did update
    useEffect(() => {
        console.log("when the count will update when count value change");
        return () => {
            console.log('useEffect cleaup phase');
        }

    }, [count]);

    //component will call every time not provide array 
    useEffect(() => {
        console.log("when the count will call every time.");
    });

    const setCountValue = () => {
        setCount(count+1);
    }
    return (
        <div>
            useEffect Count with function Component: {count} <br/>
            <button onClick={setCountValue}> Increment Value</button>
        </div>
    );
}