import { count } from "console";
import { useReducer } from "react";

interface IState {
    count: number;
}
const initialValue: IState = {count: 0};

function reducer(state: IState, action: any){
    switch(action.type){
        case 'increment':
            return {count: state.count + 1}
        case 'decrement':
            return {count: state.count - 1}
        case 'reset':
            return {count: 0}
        default:
            return {count: state.count}    
        
    }
}

export function UseReducerHook() {
    const [countState, dispatch] = useReducer(reducer, initialValue);

    return(
        <div>
            <br/>Count: {countState.count}<br/>
            <button onClick={() => dispatch({type: 'increment'})}>Increment count</button>
            <button onClick={() => dispatch({type: 'decrement'})}>Decrement count</button>
            <button onClick={() => dispatch({type: 'reset'})}>reset</button>
        </div>
    );
}