import { configureStore } from "@reduxjs/toolkit";
import rootReducer from "./rootReducer";

const middleware:any =[];

if (process.env.NODE_ENV === 'development') {
    const {createLogger} = require('redux-logger');
    const logger = createLogger({
        level: 'info',
        collapsed: true
    });
    middleware.push(logger);
}

export const store =  configureStore({
    reducer: rootReducer, //root reducer file
    middleware: (getDefaultMiddleware) => getDefaultMiddleware().concat(...middleware)  // add for logger or many can add
});

//get root reducer state fot expose make type
export type IStateReduced = ReturnType<typeof store.getState>;
//dispatch
export type IAppDispatch = ReturnType<typeof store.dispatch>;
// custom redux hook bcoz data fetch from redux
