import { addNewUserDetails, getApiObject, getUserList, updateUserDetails } from "../utils/apiUtils";
import { IApiObject } from "../models/apiUtils";
import { createSlice, PayloadAction } from "@reduxjs/toolkit";
import { Dispatch } from "react";
import { IStateReduced } from "./store";
import { map } from "lodash";

export interface IUser {
    id: string;
    first_name: string;
    last_name: string;
    email: string;
    avatar: string;
}

export interface IUserListState {
    users: IApiObject<IUser[]>;
}

export const defaultState: IUserListState = {
    users: getApiObject([], false, false, false, undefined, Error.prototype),
}

export const usersReducer = createSlice({
    name: 'userList',
    initialState: defaultState,
    reducers: {
        setUserList: (state, action: PayloadAction<IApiObject<IUser[]>>) => {
            state.users = action.payload;
        },
    },
});

export const {setUserList} = usersReducer.actions;

//update the state using action type async  above and below from backend
export const fetchUsers = () =>async (dispatch: Dispatch<any>):Promise<void> => {
try {
    dispatch(setUserList(getApiObject([], true, false, false, undefined, Error.prototype)));
    const UserResponse = await getUserList();
    dispatch(setUserList(getApiObject(UserResponse.data.data, true, false, false, undefined, Error.prototype)));   
} catch (error: any) {
        dispatch(setUserList(getApiObject([], false,false, true, error?.message, error)))
    }
}

export const updateUser = (userDetails: IUser) => async (dispatch: Dispatch<any>, getState: () => IStateReduced): Promise<void> => { 
    try { 
            const existingData = getState()?.users?.users?.data; 
            dispatch(setUserList(getApiObject([], false, false, true, undefined, Error.prototype)));
            const userResponse = await updateUserDetails(userDetails); 
            const newSelection = map(existingData, (e) => { 
                if (e.id === userDetails.id) { 
                    return userResponse.data; 
                } else { 
                    return e; 
                } 
            }); 
            dispatch(setUserList(getApiObject(newSelection, true, false, true, undefined, Error.prototype))); 
        } catch (error:any) { 
            dispatch(setUserList(getApiObject([], false, false, true, error?.message, error))); 
        } 
    };
        
export const addNewUser = (userDetails: IUser) => async (dispatch: Dispatch<any>, getState: () => IStateReduced): Promise<void> => { 
    try { 
            const existingData = getState()?.users?.users?.data; 
            dispatch(setUserList(getApiObject([], false, false, true, undefined, Error.prototype))); 
            const userResponse = await addNewUserDetails(userDetails); 
            const newSelection = [...existingData, userResponse.data]; 
            dispatch(setUserList(getApiObject(newSelection, false, false, true, undefined, Error.prototype))); 
        } catch (error:any) { 
            dispatch(setUserList(getApiObject([], false, false, true, error?.message, error))); 
        } 
    };

export default usersReducer.reducer