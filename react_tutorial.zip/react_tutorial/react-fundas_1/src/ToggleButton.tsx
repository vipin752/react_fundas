import { useState } from "react";

//using state mgmt with concepts of hooks
export function ToggleButton(){
    //
    const [checked, toggleButton] = useState(false);
    return (
        <div>
            <input type="checkbox" checked={checked} onClick={(event: any) => toggleButton(event.target.checked)} />
            Toggle with state mgmt.
        </div>
    ); 
}