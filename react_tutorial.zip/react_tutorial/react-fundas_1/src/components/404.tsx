import { Link } from "react-router-dom";
import { useLocation } from "react-router-dom";
// import { Home } from "./Home";

export function NotFound() {
    const location = useLocation();
    return (
        <div>URL not found error Component: {location.pathname}
        <br/><div>Home Url: <Link to="/home"> Home</Link> </div>
        </div>
    );
}