// import { useEffect } from "react";
import { Button, Form, FormGroup } from "react-bootstrap";
// import { useForm } from "react-hook-form";
import { IFormState } from "./Multiform";

interface IProps  {
    nextStep: ()=> void;
    submittedFormData: IFormState;
    handleChange: (value: string, fieldName: string) => void;
    reset: (value: string, fieldName1: string, fieldName2: string, fieldName3: string) => void;
}

export function StudentForm(props: IProps) {

    const {nextStep, submittedFormData, handleChange, reset} = props;
    //const { register, reset, formState, formState: { isSubmitSuccessful } } = useForm<IFormState>({defaultValues: defaultValue});

    // useEffect(() => {
    //     if (formState.isSubmitSuccessful) {
    //       reset({ ...submittedFormData });
    //     }
    //   }, [formState, submittedFormData, reset]);
    // effect runs when user state is updated
    // useEffect(() => {
    //     // reset form with user data
    //     reset(defaultValue);
    // }, [defaultValue]);

    return (
        <div>
            <Form>
                <Form.Group className="mb-3" controlId="formBasicName">
                    <Form.Label>Name:</Form.Label>
                    <Form.Control type="text" placeholder="Enter name" value={submittedFormData.name} 
                    onChange={(event) => handleChange(event.target.value, 'name')}/>
                </Form.Group>
                <Form.Group className="mb-3" controlId="formBasicFathterName">
                    <Form.Label>Father Name:</Form.Label>
                    <Form.Control type="text" placeholder="Enter Father name" value={submittedFormData.father_name} 
                    onChange={(event) => handleChange(event.target.value, 'father_name')}/>
                </Form.Group>
                <Form.Group className="mb-3" controlId="formBasicFatherName">
                    <Form.Label>Mother Name:</Form.Label>
                    <Form.Control type="text" placeholder="Enter Mother name" value={submittedFormData.mother_name} 
                    onChange={(event) => handleChange(event.target.value, 'mother_name')}/>
                </Form.Group>
                <FormGroup>
                <Button variant="primary" onClick={nextStep} type="submit">Continue</Button>{' '}
                <Button variant="primary" as="input" type="reset" onClick={(event) => reset('', 'name', 'father_name', 'mother_name')} />
                </FormGroup>
            </Form>
        </div>
    );
  }