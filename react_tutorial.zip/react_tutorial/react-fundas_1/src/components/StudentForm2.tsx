import { Button, Form, FormGroup } from "react-bootstrap";
import { IFormState } from "./Multiform";

interface IProps  {
    nextStep: ()=> void;
    prevStep: () => void;
    formState: IFormState;
    handleChange: (value: string, fieldName: string) => void;
}

export function StudentForm2(props: IProps) {

    const {nextStep, formState, handleChange, prevStep} = props;

    return (
        <div>
            <Form>
                <Form.Group className="mb-3" controlId="formBasicEmail">
                    <Form.Label>Enter Email:</Form.Label>
                    <Form.Control type="text" placeholder="Enter Email" value={formState.email} 
                    onChange={(event) => handleChange(event.target.value, 'email')}/>
                </Form.Group>

                <Form.Group className="mb-3" controlId="formBasicPhoneNumber">
                    <Form.Label>Enter Phone no:</Form.Label>
                    <Form.Control type="text" placeholder="Enter Phome no." value={formState.phone_number} 
                    onChange={(event) => handleChange(event.target.value, 'phone_number')}/>
                </Form.Group>
                <FormGroup>
                <Button variant="primary" onClick={prevStep} type="submit">Prev</Button>
                </FormGroup>
                <FormGroup>
                <Button variant="primary" onClick={nextStep} type="submit">Continue</Button>
                </FormGroup>
            </Form>
        </div>
    );
  }