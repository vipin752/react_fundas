import { Button } from "react-bootstrap";

interface IProps {
    error?: Error;
    resetErrorBoundary?: () => void;
}

export function ErorBoundaryFallbackComponent (props: IProps) {
  return(
      <div>
          <p>Some thing went wrong</p>
          <pre>{props.error?.message}</pre>
          <Button onClick={props.resetErrorBoundary}>Try Again!!!</Button>
      </div>
  );   
}