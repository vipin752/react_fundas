// import { map } from "lodash";
import { useState } from "react";
// import { useForm } from "react-hook-form";
// import { UserForm } from "../UserForm";
import { ReviewFormDetails } from "./ReviewFormDetails";
import { StudentForm } from "./StudentForm";
import { StudentForm2 } from "./StudentForm2";
import { StudentForm3 } from "./StudentForm3";

export interface IFormState {
    step: number;
    name:string;
    father_name: string;
    mother_name: string;
    email: string;
    phone_number: string;
    address: string;
    permamentAddress: string;
    pincode: string;
}

const defaultValue: IFormState = {
    step: 1,
    name:'',
    father_name: '',
    mother_name: '',
    email: '',
    phone_number: '',
    address: '',
    permamentAddress: '',
    pincode: ''
}

export function MultiForm() {
    const[submittedFormData, setSubmittedFormData] = useState<IFormState>(defaultValue);
    
    const handleFieldUpdate = (value: string, fieldName: string) => {
        setSubmittedFormData({
            ...submittedFormData,
            [fieldName]: value
        })
    }

    const handleNextStep = () => {
        setSubmittedFormData({
            ...submittedFormData,
            step: submittedFormData.step+1
        })
    }

    const handlePrevtStep = () => {
        setSubmittedFormData({
            ...submittedFormData,
            step: submittedFormData.step-1
        })
    }

    const handleFieldResetData = (value: string, fieldName1: string, fieldName2: string, fieldName3: string) => {
        setSubmittedFormData({
            ...submittedFormData,
            [fieldName1]: value,
            [fieldName2]: value,
            [fieldName3]: value,
        })
    }

    const renderForms =() => {
        if(submittedFormData.step ===1) {
            return <StudentForm nextStep={handleNextStep} handleChange={handleFieldUpdate} submittedFormData={submittedFormData} reset={handleFieldResetData}/>
        }else if(submittedFormData.step ===2) {
            return <StudentForm2 prevStep={handlePrevtStep} nextStep={handleNextStep} handleChange={handleFieldUpdate} formState={submittedFormData}/>
        }else if(submittedFormData.step ===3) {
            return <StudentForm3 prevStep={handlePrevtStep} nextStep={handleNextStep} handleChange={handleFieldUpdate} formState={submittedFormData}/>
        }else if(submittedFormData.step ===4) {
            return <ReviewFormDetails  prevStep={handlePrevtStep} formState={submittedFormData}/>
        }
        
        return <></>;
    }

    return (
        <div>{renderForms()}</div>
    );
  }