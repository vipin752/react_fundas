import { useLocalStorage } from "../hooks/useLocalStorage";

export function CustumHooks(){
    const[state, setState, remove] = useLocalStorage('key1', 'value1');

    return (
        <div>
            Local storage value is: 
            <div>
                <button onClick={() => setState('update value 1')}>update storage value</button>
            </div>
            <div>
                <button onClick={() => remove()}>remove storage value</button>
            </div>
        </div>
    );
}