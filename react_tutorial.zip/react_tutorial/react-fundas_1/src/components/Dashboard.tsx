export function Dashboard() {
    return (
        <div>Dashboard Component</div>
    );
  }