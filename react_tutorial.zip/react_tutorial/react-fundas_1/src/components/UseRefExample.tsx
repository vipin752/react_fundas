import { useRef, useState } from "react";
import { usePreviousStorage } from "../hooks/usePreviousStorage";

export function UseRefExample() {
    //useRef required default value
    const nameInputRef = useRef<HTMLInputElement>(null);
    const [count, setCount] = useState(0);
    const prevCount = usePreviousStorage(count);

    const onSubmit = () => {
        if(nameInputRef.current){
            nameInputRef.current.focus();
            console.log('nameInputRef ',nameInputRef, nameInputRef.current.value);
        }
    }

    return(
        <div>
            Count value with useState: {count} <br/>
            Previous count value with useRef: {prevCount}<br/>
            <button onClick={() => setCount(count+1)}>Increment count</button><br/>
            <input ref={nameInputRef} name="nameInout" value="Vipin"></input>
            <button onClick={onSubmit}>Submit</button>
        </div>
    );
}