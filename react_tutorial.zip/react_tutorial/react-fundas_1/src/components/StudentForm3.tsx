import { Button, Form, FormGroup } from "react-bootstrap";
import { isEmpty, isEqual } from "lodash";
import { IFormState } from "./Multiform";

interface IProps  {
    nextStep: ()=> void;
    prevStep: () => void;
    formState: IFormState;
    handleChange: (value: string, fieldName: string) => void;
}

export function StudentForm3(props: IProps) {

    const {nextStep, formState, handleChange, prevStep} = props;

    const onCheckedBoxTicked = (event: any) => {

        if(!isEmpty(formState.address) && event.target.checked){
            props.handleChange(formState.address, 'permamentAddress')
        }else if(isEqual(formState.permamentAddress, formState.address) && !event.target.checked){
            props.handleChange('', 'permamentAddress');
        }
    }

    return (
        <div>
            <Form>
                <Form.Group controlId="formBasicCommunicationAddress">
                    <Form.Label>Enter communication Address:</Form.Label><br/>
                    <Form.Control as="textarea" style={{ height: '100px' }} placeholder="Enter communication Address" value={formState.address} 
                    onChange={(event) => handleChange(event.target.value, 'address')}/>
                </Form.Group>
                <br/>
                <Form.Group className="mb-3" controlId="formBasicCheckAddress">
                    <Form.Check type="checkbox" label="Same as communication address"
                    onChange={onCheckedBoxTicked} />
                </Form.Group>
                <br/>
                <Form.Group controlId="formBasicPermamentAddress">
                    <Form.Label>Enter permament Address:</Form.Label><br/>
                    <Form.Control as="textarea" style={{ height: '100px' }} placeholder="Enter permament Address" value={formState.permamentAddress} 
                    onChange={(event) => handleChange(event.target.value, 'permamentAddress')}/>
                </Form.Group>
                <br/>
                <Form.Group className="mb-3" controlId="formBasicPincode">
                    <Form.Label>Enter pincode:</Form.Label>
                    <Form.Control type="text" placeholder="Enter pincode no." value={formState.pincode} 
                    onChange={(event) => handleChange(event.target.value, 'pincode')}/>
                </Form.Group>
                <FormGroup>
                <Button variant="primary" onClick={prevStep} type="submit">Prev</Button>
                </FormGroup>
                <FormGroup>
                <Button variant="primary" onClick={nextStep} type="submit">Continue</Button>
                </FormGroup>
            </Form>
        </div>
    );
  }