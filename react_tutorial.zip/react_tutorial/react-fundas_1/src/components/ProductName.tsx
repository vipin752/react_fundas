import { Link } from "react-router-dom";

export function ProductName() {
    return (
        <div>
            <ul>
                <li>
                    <Link to={`product/product1`} >Product A </Link>
                </li>
                <li>
                    <Link to={`product/product2`} >Product B </Link>
                </li>
                <li>
                    <Link to={`product/product3`} >Product C </Link>
                </li>
                <li>
                    <Link to={`product/product4`} >Product D </Link>
                </li>
            </ul>
        </div>
    );
}