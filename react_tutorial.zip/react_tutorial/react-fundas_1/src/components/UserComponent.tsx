
export function UserComponent () {
  return(
      <div>
         {new Error('Error in the user component')}
      </div>
  );   
}
//install the react error boundary