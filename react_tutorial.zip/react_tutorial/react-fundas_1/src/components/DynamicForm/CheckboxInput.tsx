import { Form } from "react-bootstrap";
import { IFormFields } from "../../models/formFileds";

interface IProps {
    field: IFormFields;
    value: string;
    onFieldChange: (fieldName: string, value: boolean) => void;
}
export function CheckboxInput(props: IProps) {
    const { field, value, onFieldChange } = props;
    return (
        <div>
            <Form.Group className="mb-3" controlId="formBasicCheckbox">
                <Form.Check type={field.type} label={field.label} value={value} onChange={(e) => onFieldChange(field.id, e.target.checked)} />
            </Form.Group>
        </div>
    );
}