import { map, reduce } from "lodash";
import { useEffect, useState } from "react";
import { Button, Form } from "react-bootstrap";
import { Fields, formFields, IFormFields } from "../../models/formFileds";
import { TextInput } from "./TextInput";
import { CheckboxInput } from "./CheckboxInput";


export function DynamicForm() {

    const [formValue, setFormValue] = useState({});

    useEffect ( () => {
        const fields = reduce(formFields, (obj, field) => {
            obj[field?.id] = '';
            return obj;
        }, {});
        setFormValue(fields);
    },[]);

    const onChangeField = (field: string, value: any) => {
        setFormValue({
            ...formValue,
            [field]: value
        })

    }

    const onSubmit = () => {
        console.log('from submitted', formValue);
    }

    const renderForm = (f: IFormFields) => {
        switch(f.component) {
            case Fields.TEXT:
                return (
                    <TextInput onFieldChange={onChangeField} value={formValue[f.id]} field={f} key={f.id}/>
                );
            case Fields.CHECKBOX:
                return(
                    <CheckboxInput onFieldChange={onChangeField} value={formValue[f.id]} field={f} key={f.id}/>
                );
        }
    }

    return (
    <Form>
        <b>Dynamic form in React</b>
        {map(formFields, (f) => renderForm(f))}
        <Button className="mt-3" variant="primary" onClick={onSubmit}> Submit</Button>
    </Form>
    );
}