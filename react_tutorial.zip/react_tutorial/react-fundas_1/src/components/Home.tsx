import { Button } from "react-bootstrap";
import { useHistory } from "react-router-dom";

export function Home() {
  const history = useHistory();
  const onClick = () => {
    history.push('./product');
  }
  return (
      <div>Home Component
      <Button onClick={onClick}>About route</Button>
      </div>
  );
}