import { ListGroup, Button, Form, FormGroup } from "react-bootstrap";
import { isEmpty, isEqual } from "lodash";
import { IFormState } from "./Multiform";

interface IProps  {
    prevStep: () => void;
    formState: IFormState;
}

export function ReviewFormDetails(props: IProps) {

    const {formState, prevStep} = props;

    const onConfirmed = (event: any) => {
        console.log('onConfirmed', event);
        //backend api call or do reset
    }

    return (
        <div>
            <ListGroup variant="flush">
            <ListGroup.Item>Name: {formState.name}</ListGroup.Item>
            <ListGroup.Item>Father Name: {formState.father_name}</ListGroup.Item>
            <ListGroup.Item>Mother Name: {formState.mother_name}</ListGroup.Item>
            <ListGroup.Item>Email: {formState.email}</ListGroup.Item>
            <ListGroup.Item>Phone no: {formState.phone_number}</ListGroup.Item>
            <ListGroup.Item>Address: {formState.address}</ListGroup.Item>
            <ListGroup.Item>Permament Address: {formState.permamentAddress}</ListGroup.Item>
            <ListGroup.Item>Pincode: {formState.pincode}</ListGroup.Item>
            </ListGroup>
            <Form>
                <FormGroup>
                <Button variant="primary" onClick={prevStep} type="submit">Prev</Button>
                </FormGroup>
            </Form>
        </div>
    );
  }