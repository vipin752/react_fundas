
interface IProps{
    name?: string;
}
//prpos are read only for change require to use useState
export function Welcome(props: IProps){
    const {name} = props;
    return <div>{name}</div>;
}