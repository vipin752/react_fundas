// import React, { useState, useEffect } from "react";
import NewWindow from "react-new-window";
import { MultiForm } from "./components/Multiform";
// import parse from "html-react-parser";

// const dataX12 =
//  '<html><head>Vipin dube</head><body></body></html>';
// // // const dataX12a =
// //   // '<style>.yolo{background-color:yellow; color: red}</style><div><h1 class="yolo">Hello World</h1><button onclick="myFunction()">Try it</button><script>function myFunction() {console.log("Hello! I am an alert box!");}</script>';

//  let htmlX12 = parse(dataX12);

// const createMarkup = () => {
//   return { __html: dataX12 };
// };

export const Viewer = () => {
  return (
    <NewWindow title="vipin" features={{height: 0, width: 0, fullscreen: 'yes'}}>
      {/* <html dangerouslySetInnerHTML={createMarkup()} /> */}
      <MultiForm/>
    </NewWindow>
  );
};
