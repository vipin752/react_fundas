//import { map } from "lodash";
import { useEffect } from "react";
import { Header } from "../components/Header";
import { useUserContext } from "../context/UserContextProvider";
import { fetchUserDetails } from "../reducer/UserDetailsReducer";

export function UseContextProvider() {
    const { userInfo: { user }, dispatch } = useUserContext();

    console.log('user', user);

    useEffect(() => {
        fetchUserDetails(dispatch);
    }, [dispatch])

    return (
        <div>
            <Header />
            user Details:
            {/* {map(user, (u, index) => <div key={index}>{u?.first_name} {' '} {u?.last_name}</div>)} */}
        </div>
    )
}