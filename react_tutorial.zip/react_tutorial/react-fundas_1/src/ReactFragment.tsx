import { Fragment } from "react"

export function ReactFragment () {
    const items = ['it1', 'it2', 'it3', 'it4'];
    return(
        // <div>
        // <Fragment>
        <>
        <div>
            <p>Paragraph 1</p>
            <p>Paragraph 2</p>
        </div>
        <div>
            <p>Paragraph div 1</p>
            <p>Paragraph div 2</p>
        </div>
        {items.map((item) => (
            <Fragment key={item}>
                <p>{item}</p>
            </Fragment>
        ))}
         </>
         //</Fragment>
        // </div>
    );
}