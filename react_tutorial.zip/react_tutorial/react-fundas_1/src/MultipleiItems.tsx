import { useState } from "react";

const defaultItems = [
    {id: "id1", value:"value1"},
    {id: "id2", value:"value2"},
    {id: "id3", value:"value3"},
    {id: "id4", value:"value4"},
    {id: "id5", value:"value5"}
];

export function MultipleItems()  {
  const [items, setItems] = useState(defaultItems);
  const addItem = () => {
      const item = defaultItems.find((i) => !items.includes(i));
      if(item){
          setItems([...items, item]);
      }
  }
  const removeItem = (item: any) => {
        setItems(items.filter((i) => i !== item));
  }
  return (
      <div>
          <button onClick={addItem}>Add Item</button>
          <ul style={{listStyle: "none", paddingLeft: 1}}>
              {items.map((item, key) => <li key={item.id}>
                  <label>{item.id}</label>
                  <input defaultValue={item.value} />
                  <button onClick={() => removeItem(item)}> Remove Item</button>
              </li>)}
          </ul>
      </div>
  );
}