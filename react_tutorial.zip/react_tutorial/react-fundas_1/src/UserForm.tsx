import { useEffect, useState } from "react";
import NewWindow from 'react-new-window';
import React from 'react';
import {Viewer} from "./Viewer";

interface IUserForm{
    name: string;
    age: number;
}

const defaultUserForm = {
    name: '',
    age: 0
}
//using state mgmt with concepts of hooks
export function UserForm(){
    const [form, setForm] = useState<IUserForm>(defaultUserForm);
    const [isOpen, setOpen] = useState(false);

  const openWindow = () => {
    setOpen(!isOpen);
  };

  useEffect(() => {
    // Update the document title using the browser API
    document.title = `vipin`;
  }, []);

    const onChangeName = (event: any) => {
        setForm({
            ...form,
            name: event.target.value,
        });
    }
    const onChangeAge = (event: any) => {
        setForm({
            ...form,
            age: event.target.value,
        });
    }
    const onSubmitButton = () => {
        console.log("form: ", form);
        //we can call api to update the record in db;
    }
   
    return (
        <div>
            UserName: <input type="text" name="username" value = {form.name} onChange={onChangeName} /><br/>
            UserAge: <input type="number" name="userage" value = {form.age} onChange={onChangeAge} /><br/>
            <button onClick={openWindow}>Submit</button>
            {isOpen && <Viewer />}
        </div>
    );
}