// import React, { useReducer } from 'react';
//import logo from './logo.svg';
import './App.css';
import {Welcome} from "./Welcome";
//import {ToggleButton} from "./ToggleButton";
//import { UserForm } from './UserForm';
//import { LifeCycleMehodWithFunction } from './LifeCycleMehtod';
//import { ConditionalRender } from './ConditionalRender';
import { QueryClient, QueryClientProvider } from 'react-query';
//import { MultipleItems } from './MultipleiItems';
//import { CustumHooks } from './components/CustumHooks';
//import { UseRefExample } from './components/UseRefExample';
//import { UseReducerHook } from './hooks/UseReducerHooks';
//import { AppRoutes } from './components/AppRoutes';
import { HashRouter } from 'react-router-dom';
// import { MultiForm } from './components/Multiform';
import { Provider } from 'react-redux';
import { store } from './redux/store'; 
//import { UserList } from './components/UserList';
// import { DynamicForm } from './components/DynamicForm/DynamicForm';
// import { NavLinkComponent } from './components/NavLinkComponent';
import 'bootstrap/dist/css/bootstrap.min.css';
import { ReactFragment } from './ReactFragment';
import { UserForm } from './UserForm';
import { ErrorBoundary } from 'react-error-boundary';
import { ErorBoundaryFallbackComponent } from './components/ErrorBoundaryFallbackComponent';
import { ErorBoundariesHandler } from './components/ErrorBoundariesHandler';

// function sumNumbers(a: number, b: number) {
//   return a + b;
// }

// interface Iprops {
//   a: number;
//   b: number;
// }

// function SumComponent(props: Iprops){
//   return <>{props.a + props.b}</>;
// }
const queryClient = new QueryClient();

function App() {
  // const value = sumNumbers(5,4);
  return (
    <HashRouter>
      <Provider store={store}>
    <QueryClientProvider client={queryClient}>
    <div className="App">
      <header className="App-header">
        {/* <img src={logo} className="App-logo" alt="logo" />
        <p>
          Edit <code>src/App.tsx</code> and save to reload.
        </p>
        <a
          className="App-link"
          href="https://reactjs.org"
          target="_blank"
          rel="noopener noreferrer"
        >
          Learn React with Vipin Dube!
        </a>
        <div>Sum of two numbers is: {value}</div>
        <div>Sum of two numbers using sumComponent: <SumComponent a={7} b={11}/> </div> */}
        <Welcome name="Vipin Dube! Son of Ashok Dube!" />
        {/* <ReactFragment/> */}
        {/* <Welcome name="Vipin Dube" /> */}
        {/* <ToggleButton/> */}
         {/* <UserForm/> */}
        {/*<LifeCycleMehodWithFunction initialValue={0}/>
        <ConditionalRender/>
        <MultipleItems/>
        <CustumHooks/> */}
        {/* <UseRefExample/>
        <UseReducerHook/> */}
        {/* <AppRoutes/> */}
        {/* {<NavLinkComponent/>} */}
        {/* {<MultiForm/>} */}
        {/* {<UserList/>} */}
        {/* <DynamicForm/> */}
        <ErrorBoundary FallbackComponent={ErorBoundaryFallbackComponent}>
          <ErorBoundariesHandler/>
        </ErrorBoundary>
      </header>
    </div>
    </QueryClientProvider>
    </Provider>
    </HashRouter>
  );
}

export default App;
