import { filter } from "lodash";
import { IResource } from "../model/ApiUtils";

export interface IDeleteResourcePayload {
    id: number,
}

const mockResourceData = new Array(10).fill(0).map((v, i) => ({
    id: i,
    title: `Post= ${i}`,
}));

let data = mockResourceData;

export const fetchResource = async (): Promise<IResource[]>=> {
    await new Promise((resolve) => setTimeout(resolve, 1000));
    return data ?? [];
}

export const deleteResource = async ({id, }: IDeleteResourcePayload): Promise<void>=> {
    await new Promise((resolve) => setTimeout(resolve, 1000));
    data = filter(data, (d) => d.id !== id);
}