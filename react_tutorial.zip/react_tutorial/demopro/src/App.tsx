// import React from 'react';
// import logo from './logo.svg';
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'react-toastify/dist/ReactToastify.css';
import { Container } from 'react-bootstrap';
import { Resource } from './components/Resource';
import { QueryClient, QueryClientProvider } from 'react-query';
import { toast, ToastContainer } from 'react-toastify';
// import { ToastNotifications } from './components/ToastNotifications';

const overrides = {
  defaultOptions: {
    queries: {
      retry: false,
      refetchOnWindowFocus: false,
    }
  }
}

// const notify = () => toast("Wow so easy!");

const client = new QueryClient(overrides);

function App() {
  return (
    <QueryClientProvider client={client}>
      {/* <button onClick={notify}>Notify!</button> */}
      <ToastContainer/>
      <Container>
        <Resource/>
    </Container>
    </QueryClientProvider>
  );
}

export default App;
