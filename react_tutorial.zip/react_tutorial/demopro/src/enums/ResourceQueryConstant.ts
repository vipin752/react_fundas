export enum ResourceQueryConstant {
 RESOURCE = "RESOURCE",
}