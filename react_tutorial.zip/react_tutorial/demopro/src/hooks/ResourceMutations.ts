import { useMutation, UseMutationOptions } from "react-query";
import { deleteResource, IDeleteResourcePayload } from "../utils/ApiUtils";

export function useDeleteResource (options?: UseMutationOptions<void, Error, IDeleteResourcePayload>) {
    return useMutation(deleteResource, {
        ...options,
    })
}