import { useQuery, UseQueryOptions } from "react-query";
import { ResourceQueryConstant } from "../enums/ResourceQueryConstant";
import { IResource } from "../model/ApiUtils";
import { fetchResource } from "../utils/ApiUtils";

export function useGetResource (options?: UseQueryOptions<IResource[], Error>) {
  return useQuery<IResource[], Error>([ResourceQueryConstant.RESOURCE], fetchResource, {
      ...options,
  });
}