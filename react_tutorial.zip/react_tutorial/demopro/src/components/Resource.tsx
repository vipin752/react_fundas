import { ListGroup, Spinner } from "react-bootstrap";
import { useGetResource } from "../hooks/ResourceQuery";
import {map} from "lodash";
import { Button } from "react-bootstrap";
import { useDeleteResource } from "../hooks/ResourceMutations";
import { ToastNotifications } from "./ToastNotifications";

export function Resource () {
    const {data, isLoading, isError, refetch} = useGetResource();
    const deleteMutate = useDeleteResource();
    // console.log('data:', data)

    if(isLoading) {
        return <Spinner animation="border"></Spinner>
    } else if(isError) {
        return<div>Data Fetching Error</div>
    }

    const deleteResource = async(id: number) => {
        try {
            await deleteMutate.mutateAsync({
                id:id,
            });
            refetch();
            ToastNotifications.addSuccessMessage('Successfully deleted post record!!!')
        } catch (error) {
            console.log('error in resource: ',error)
        }
    }

    const renderButtons = (id: number) => {
        return(
            <div>
                <Button variant="outline-primary">Edit</Button>
                <Button disabled={deleteMutate.isLoading} onClick={() => deleteResource(id)} variant="outline-primary">Delete</Button>
            </div>
        );
    }
    return(
        <div className="mt-2">
            {map(data, (d) => 
                <ListGroup key={d.id} horizontal="sm">
                <ListGroup.Item>{d.id}</ListGroup.Item>
                <ListGroup.Item>{d.title}</ListGroup.Item>
                {renderButtons(d.id)}
            </ListGroup>
            )}
        </div>
    );
}