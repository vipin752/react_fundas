export interface IResource {
    id: any;
    title: any;
}